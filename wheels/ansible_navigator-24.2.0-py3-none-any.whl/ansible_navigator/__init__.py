"""The ansible-navigator application."""
